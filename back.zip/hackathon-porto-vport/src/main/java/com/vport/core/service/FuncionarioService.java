package com.vport.core.service;

import com.vport.core.domain.entity.Funcionario;

public interface FuncionarioService {
    void save(Funcionario funcionario);
}

package com.vport.core.service.implementation;

import com.vport.core.domain.entity.Funcionario;
import com.vport.core.domain.repository.FuncionarioRepository;
import com.vport.core.service.FuncionarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FuncionarioServiceImpl implements FuncionarioService {

    @Autowired
    private FuncionarioRepository funcionarioRepository;

    @Override
    public void save(Funcionario funcionario) {

        //** salva no firebase **//

        funcionarioRepository.save(funcionario);
    }
}

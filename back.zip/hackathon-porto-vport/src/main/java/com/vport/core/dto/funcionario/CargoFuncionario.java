package com.vport.core.dto.funcionario;

public enum CargoFuncionario {
    OPERARIO,
    BRIGADISTA,
    LIDER_EMERGENCIA,
    SOCORRISTA,
    LOGISTICA,
    BOMBEIRO
}

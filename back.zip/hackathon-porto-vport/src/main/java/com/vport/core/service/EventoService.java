package com.vport.core.service;

import com.google.firebase.messaging.FirebaseMessagingException;
import com.vport.core.core.exception.EventoException;
import com.vport.core.core.exception.FuncionarioException;
import com.vport.core.domain.entity.Evento;
import com.vport.core.dto.evento.EventoDto;
import java.util.List;
import java.util.Optional;

public interface EventoService {

    void save(EventoDto eventoDto) throws FuncionarioException, EventoException, FirebaseMessagingException;
    List<Evento> findAll();
    Optional<Evento> findById(Long id);
    void update(Evento evento) throws EventoException;
}

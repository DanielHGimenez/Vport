package com.vport.core;

import com.google.auth.oauth2.AccessToken;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.messaging.FirebaseMessaging;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

@SpringBootApplication
public class CoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoreApplication.class, args);
	}

	@Bean
	public FirebaseApp firebaseApp() throws IOException {

		String config = "{\n" +
				"  \"type\": \"service_account\",\n" +
				"  \"project_id\": \"com-vport-app-porto\",\n" +
				"  \"private_key_id\": \"e8f301420382998957ec12363716fc2edc02ec38\",\n" +
				"  \"private_key\": \"-----BEGIN PRIVATE KEY-----\\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQClBaSYCGHdTHxc\\n7OHjy8jT40Xug4c67MH3IsCMSfSH3vu45iasupGYC7KAFK6Feq4ugMGasypR56Ia\\nc5B88+rZ2qPUC+bIcEKX9+dXf5WXgM6ziZ3SHO3Ti4j1XngN+6XOOPShU685OjqP\\nqmlx7Fjkn0cFfuNblk6FTU0v7QUx6P+r4g0I0RVTMl6G1SDQu+5v668Q7B89mjNX\\nwbNYGmqkt0b3uwkfAsXzVnlCxdtRqXeTUE/gf5SeziXMm8ehanM5dft3mqOGGZ48\\ny17cbk46jKLTZzUX/0w4RhDA943bXOVC4GNf6or5ec8JCItN7qCMOInwR+ASTYdC\\nmAEi1X/rAgMBAAECggEAFBAEkRXrzVDVic1O2o1VpCpsanFZM9kW7SnaHkmGI4Kr\\njduFS4NUh2yx+I+1zAqR5JtzbjsRY8B1Mna8U+9VAm6/c4c4OUQqBHnM3r68fB0v\\n2XSwrZvQxOL2SrEqiAtWfs+T2407Wgoclod8Ua+5+vRBA90HsoR/6rBEOGsTh5v/\\nJ4l09g2gADRg9r82GKbS/6XvlAWGOnVSiMDt1TXmnpo069yq9FobO0tGaJWzIW3D\\nAGscBJS7aiqYBPSQH90N5YvH0QjH3V/QbdEK96xoqjMWjKifTzx2NAjuzwJ0ligW\\nTzUei149fO3T5UlurhkX2w4rHmTYWwFTU5tu/McB6QKBgQDV/pL3MJp3sO3YXww+\\nryp/VpgA5DrF6rN9YUYdCVrgOdp+OjZovQ9EDpSsUFSp0sFamwdrkaFEiNihTIYb\\nBirfIDYE7ZMTzz9NEfKijFWQsiD9JgIy438rKCJ6cYdMJ4b7V2D83wacmaklCHW1\\nj1RimAYVcMGY6LsTWiuPi4iz9wKBgQDFaijH/7xT6XoGitMgiB5S7WLT4ry8fONQ\\n4/uFJVHoiq/yN74XXpuU052UD24247DYwJxfYtb8w/7ZxtkYn8BiVOSro8SNbZXr\\nPe1kLdhG6UzKBjplDUGBMLmbQpl4h0rtKpDE6t9MYXyFh/rMKdv4cQgR+E1EKF9C\\nXabY726urQKBgCtSwsYwnNUmiMCJXZ1DMUNecJ+dlRiEj5oOm3c9cZx7mfR8LI+/\\n1ttcaFUKXlmTRXnmcPYiIZgSbGkbaPsHoJ5TkxwkTOZxysr7mze1WY1Vwr/9dex/\\nijtegLxxR4bvabBw3D3VmS0THt9UeyAqyFa9mF222jruwxED7FW/Vgm5AoGBAIf3\\nsBLfzoQ04Hi1EOjtF4WiPlkVZ0yi76V9AHUZ2SpCqyA2yFQsMxf0ECoz3oMrm1gO\\ngSUpXE1HaLXxwQC2triDI+QbrXqDKaiWRHSlJrrgYKUcWQfUc3NZbdzDqBRdinuC\\nv6cA5b8jvbHykAgiJIEeyKIn1H/HFqUM/6eWcTMZAoGBANPrbV8wIacPDJh91T1O\\ngkY5sOW71OY32q14re8GZvOABQJxfaxjj9PsCeSqfWPAhJcYfRajvGrOBJj30VQU\\nxdDrEI/SsaF65vfqjMCRnnuyf2Fe47kZ8K1gOKqsVnms9A0OmglP9M5CHFuIBP1K\\npAt+qj/FJjOivI3MfKnXuAC2\\n-----END PRIVATE KEY-----\\n\",\n" +
				"  \"client_email\": \"firebase-adminsdk-m6eqr@com-vport-app-porto.iam.gserviceaccount.com\",\n" +
				"  \"client_id\": \"114620378078245277275\",\n" +
				"  \"auth_uri\": \"https://accounts.google.com/o/oauth2/auth\",\n" +
				"  \"token_uri\": \"https://oauth2.googleapis.com/token\",\n" +
				"  \"auth_provider_x509_cert_url\": \"https://www.googleapis.com/oauth2/v1/certs\",\n" +
				"  \"client_x509_cert_url\": \"https://www.googleapis.com/robot/v1/metadata/x509/firebase-adminsdk-m6eqr%40com-vport-app-porto.iam.gserviceaccount.com\"\n" +
				"}\n";

		InputStream is = new ByteArrayInputStream(config.getBytes());

		FirebaseOptions options = new FirebaseOptions.Builder()
				.setCredentials(GoogleCredentials.fromStream(is))
				.setDatabaseUrl("https://com-vport-app-porto.firebaseio.com")
				.build();

		return FirebaseApp.initializeApp(options);
	}

	@Bean
	public FirebaseMessaging firebaseMessaging(FirebaseApp firebaseApp) {
		return FirebaseMessaging.getInstance(firebaseApp);
	}

	@Bean
	public FirebaseAuth firebaseAuth(FirebaseApp firebaseApp) {
		return FirebaseAuth.getInstance(firebaseApp);
	}


	@Bean
	public WebMvcConfigurer corsConfigurer() {
		return new WebMvcConfigurerAdapter() {
			@Override
			public void addCorsMappings(CorsRegistry registry) {
				registry.addMapping("/products").allowedOrigins("http://localhost:8888");
			}
		};
	}

}

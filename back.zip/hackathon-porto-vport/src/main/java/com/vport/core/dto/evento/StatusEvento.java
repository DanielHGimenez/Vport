package com.vport.core.dto.evento;

public enum StatusEvento {
    PENDENTE,
    ATIVO,
    EM_ATENDIMENTO
}

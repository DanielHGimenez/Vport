package com.vport.core.service.implementation;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseToken;
import com.vport.core.service.FirebaseAuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FirebaseAuthServiceImpl implements FirebaseAuthService {

    @Autowired
    private FirebaseAuth firebaseAuth;

    public FirebaseToken getUserAuthenticated(String token) throws FirebaseAuthException {
        try {
            return firebaseAuth.verifyIdToken(token, true);
        } catch (FirebaseAuthException e) {
            if (e.getErrorCode().equals("id-token-revoked")) {
                return null;
            }
            throw e;
        }
    }

}

package com.vport.core.dto.evento;

public enum ClassificacaoEvento {
    INCENDIO,
    VAZAMENTO,
    DESASTRE_NATURAL
}

package com.vport.core.domain.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.vport.core.dto.funcionario.CargoFuncionario;
import lombok.*;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import java.util.List;

@Setter
@Getter
@Builder
@Entity
@AllArgsConstructor
@NoArgsConstructor
public class Funcionario {
    @Id
    private String uuid;
    private String nome;
    private CargoFuncionario cargoFuncionario;
    @OneToMany(mappedBy = "funcionarioSolicitante")
    @JsonBackReference
    private List<Evento> listEvento;
}

package com.vport.core.dto.evento;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Getter;
import lombok.Setter;
import java.time.LocalDateTime;
import java.util.Date;

@Getter
@Setter
public class EventoDto {
    private long id;
    private ClassificacaoEvento classificacaoEvento;
    @JsonFormat(pattern="dd-MM-yyyy HH:mm:ss")
    private Date data;
    private GrauPericulosidadeEvento grauPericulosidadeEvento;
    private StatusEvento statusEvento;
    private Integer qtVitimas;
    private String funcionarioUuid;
    private String localizacao;
}

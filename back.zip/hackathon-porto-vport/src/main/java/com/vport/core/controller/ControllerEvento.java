package com.vport.core.controller;

import com.google.firebase.messaging.FirebaseMessagingException;
import com.vport.core.core.exception.EventoException;
import com.vport.core.core.exception.FuncionarioException;
import com.vport.core.domain.entity.Evento;
import com.vport.core.dto.evento.EventoDto;
import com.vport.core.dto.evento.StatusEvento;
import com.vport.core.service.EventoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/evento")
public class ControllerEvento {

    @Autowired
    private EventoService eventoService;

    @PostMapping
    public ResponseEntity<?> save(@RequestBody EventoDto eventoDto) throws FuncionarioException, FirebaseMessagingException, EventoException {

        eventoService.save(eventoDto);
        return new ResponseEntity<>(HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Evento>> findAll() {
        return new ResponseEntity<>(eventoService.findAll(), HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Evento> findById(@PathVariable Long id) {

        Optional<Evento> eventoOpt =  eventoService.findById(id);
        return eventoOpt.map(evento -> new ResponseEntity<>(evento, HttpStatus.OK))
                .orElseGet(() -> ResponseEntity
                .notFound()
                .build());
    }

    @PutMapping("/{id}")
    public void update(@PathVariable Long id, @RequestBody Evento evento) throws EventoException {
        evento.setId(id);
        eventoService.update(evento);
    }

    
}

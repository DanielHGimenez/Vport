package com.vport.core.controller;

import com.vport.core.domain.entity.Funcionario;
import com.vport.core.service.FuncionarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("funcionario")
@RestController
public class FuncionarioController {

    @Autowired
    private FuncionarioService funcionarioService;

    @PostMapping
    public void save(@RequestBody Funcionario funcionario) {
        funcionarioService.save(funcionario);
    }
}

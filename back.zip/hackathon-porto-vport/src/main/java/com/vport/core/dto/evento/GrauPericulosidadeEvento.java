package com.vport.core.dto.evento;

public enum GrauPericulosidadeEvento {
    DESPREZIVEL,
    MARGINAL,
    CRITICO,
    CATASTROFICO
}


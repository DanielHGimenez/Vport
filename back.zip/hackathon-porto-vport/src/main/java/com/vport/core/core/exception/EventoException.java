package com.vport.core.core.exception;

public class EventoException extends Exception {

    public EventoException() {
        super("Evento não encontrado");
    }

    public EventoException(String message) {
        super(message);
    }

}

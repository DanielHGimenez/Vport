package com.vport.core.core.exception;

public class FuncionarioException extends Exception{

    public FuncionarioException() {
        super("Funcionário não encontrado");
    }

    public FuncionarioException(String message) {
        super(message);
    }
}

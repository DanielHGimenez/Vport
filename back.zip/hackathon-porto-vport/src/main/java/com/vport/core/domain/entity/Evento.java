package com.vport.core.domain.entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.vport.core.dto.evento.ClassificacaoEvento;
import com.vport.core.dto.evento.GrauPericulosidadeEvento;
import com.vport.core.dto.evento.StatusEvento;
import lombok.*;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import java.time.LocalDateTime;
import java.util.Date;

@Builder
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Evento {
    @Id @GeneratedValue
    private Long id;
    private ClassificacaoEvento classificacaoEvento;
    private Date data;
    private GrauPericulosidadeEvento grauPericulosidadeEvento;
    private StatusEvento statusEvento;
    private Integer qtVitimas;
    @ManyToOne
    @JsonManagedReference
    private Funcionario funcionarioSolicitante;
    private String localizacao;

    public Evento(Long id, StatusEvento statusEvento) {
        this.id = id;
        this.statusEvento = statusEvento;
    }
}



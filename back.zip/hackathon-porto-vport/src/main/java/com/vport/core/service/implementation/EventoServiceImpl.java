package com.vport.core.service.implementation;

import autovalue.shaded.com.google$.common.base.$Throwables;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.vport.core.core.exception.EventoException;
import com.vport.core.core.exception.FuncionarioException;
import com.vport.core.domain.entity.Evento;
import com.vport.core.domain.entity.Funcionario;
import com.vport.core.domain.repository.EventoRepository;
import com.vport.core.domain.repository.FuncionarioRepository;
import com.vport.core.dto.evento.EventoDto;
import com.vport.core.dto.evento.StatusEvento;
import com.vport.core.dto.funcionario.CargoFuncionario;
import com.vport.core.service.EventoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import javax.transaction.Transactional;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@Service
public class EventoServiceImpl implements EventoService {

    @Autowired
    private EventoRepository eventoRepository;

    @Autowired
    private FuncionarioRepository funcionarioRepository;

    @Autowired
    private FirebaseMessaging firebaseMessaging;

    @Override
    public void save(EventoDto eventoDto) throws EventoException, FirebaseMessagingException {

        Optional<Funcionario> funcionarioOpt = funcionarioRepository.findByUuid(eventoDto.getFuncionarioUuid());

        if(!funcionarioOpt.isPresent()) throw new EventoException();

        Funcionario funcionario = funcionarioOpt.get();

        StatusEvento statusEvento = funcionario.getCargoFuncionario() != CargoFuncionario.LIDER_EMERGENCIA ? StatusEvento.PENDENTE : StatusEvento.ATIVO;

         Evento evento = eventoRepository.save(Evento.builder()
            .funcionarioSolicitante(funcionario)
            .classificacaoEvento(eventoDto.getClassificacaoEvento())
            .data(eventoDto.getData())
            .grauPericulosidadeEvento(eventoDto.getGrauPericulosidadeEvento())
            .statusEvento(statusEvento)
            .build());

        String topico = "addEvento";

        Message message = Message.builder()
            .putData("id", evento.getId().toString())
            .putData("classificacao", evento.getClassificacaoEvento().toString())
            .putData("localizacao", "Terminal 1")
            .putData("grauPericulosidade", evento.getGrauPericulosidadeEvento().toString())
            .setTopic(topico)
            .build();

        firebaseMessaging.send(message);
    }

    @Override
    public List<Evento> findAll() { return eventoRepository.findAll(); }

    @Override
    public Optional<Evento> findById(Long id) {
        return eventoRepository.findById(id);
    }

    @Override
    @Transactional
    public void update(Evento evento) throws EventoException {

        Optional<Evento> eventOpt = eventoRepository.findById(evento.getId());

        if(!eventOpt.isPresent()) throw new EventoException();

        Evento eventoUpdate = eventOpt.get();
        eventoUpdate.setClassificacaoEvento(evento.getClassificacaoEvento());
        eventoUpdate.setGrauPericulosidadeEvento(evento.getGrauPericulosidadeEvento());
        eventoUpdate.setStatusEvento(evento.getStatusEvento());
        eventoUpdate.setQtVitimas(evento.getQtVitimas());
    }
}
